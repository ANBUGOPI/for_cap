sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("com.sampleapp.controller.View1",{onInit:function(){}})});
//# sourceMappingURL=View1.controller.js.map